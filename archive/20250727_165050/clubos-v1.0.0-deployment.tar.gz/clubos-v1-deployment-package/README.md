# ClubOS V1 Deployment Package

Welcome to the ClubOS V1 deployment package for golf simulator facilities!

## 📁 Package Contents

### /docs
- `DEPLOYMENT_GUIDE.md` - Complete deployment guide
- `TECHNICAL_AUDIT.md` - Technical specifications
- `SETUP_GUIDE.md` - Detailed setup instructions
- `PRICING_SHEET.md` - Pricing and ROI information
- `IMPLEMENTATION_TIMELINE.md` - 4-week rollout plan

### /scripts
- `quick-start.sh` - Quick start script
- `deploy-facility.sh` - Automated deployment tool

### /config
- `.env.backend.template` - Backend configuration
- `.env.frontend.template` - Frontend configuration

### /templates
- `SERVICE_AGREEMENT_TEMPLATE.md` - Contract template

## 🚀 Getting Started

1. Run the quick start script:
   ```bash
   cd scripts
   ./quick-start.sh
   ```

2. Review the documentation in the `/docs` folder

3. Contact our implementation team:
   - Email: support@clubos.com
   - Phone: 1-800-CLUBOS1

## 💰 Pricing

- **Monthly Subscription**: $2,000
- **No Setup Fees**
- **Month-to-Month Contract**
- **10% Annual Discount Available**

## 📞 Support

- Business Hours: M-F 9AM-5PM EST
- Email: support@clubos.com
- Phone: 1-800-CLUBOS1
- Emergency: Available with priority support add-on

---

© 2024 ClubOS, Inc. All rights reserved.
