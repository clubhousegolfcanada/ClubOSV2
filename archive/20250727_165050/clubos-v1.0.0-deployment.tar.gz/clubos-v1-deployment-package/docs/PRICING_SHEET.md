# ClubOS V1 Pricing Sheet

## Monthly Subscription: $2,000

### Included Services
- ✅ Complete ClubOS platform access
- ✅ Up to 10,000 AI-powered requests/month
- ✅ All infrastructure and hosting
- ✅ Business hours technical support
- ✅ Regular feature updates
- ✅ Daily automated backups
- ✅ 99.9% uptime SLA

### Optional Add-Ons
- **Additional AI Requests**: $0.10 per request over 10k
- **Priority 24/7 Support**: +$500/month
- **Custom Training Session**: $500 per 2-hour session
- **Knowledge Base Import**: $1,000 one-time
- **Custom Branding**: $500 one-time

### Implementation Costs
- **Standard Setup**: Included
- **Data Migration**: Quote based on volume
- **Custom Integrations**: Starting at $2,500

### Contract Terms
- Month-to-month billing
- No setup fees
- 30-day cancellation notice
- Annual discount: 10% (pay $21,600/year)

### ROI Calculator
**Monthly Savings**:
- Staff time (20 hrs @ $20/hr): $1,600
- Increased efficiency: $500
- Reduced no-shows: $300
- **Total Value**: $2,400/month
- **Net ROI**: $400/month (20%)

Contact: sales@clubos.com | 1-800-CLUBOS1
