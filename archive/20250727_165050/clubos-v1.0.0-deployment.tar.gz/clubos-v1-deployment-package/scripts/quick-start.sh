#!/bin/bash
# ClubOS V1 Quick Start Script

echo "🚀 ClubOS V1 Quick Start"
echo "========================"

# Check prerequisites
echo "Checking prerequisites..."
command -v node >/dev/null 2>&1 || { echo "❌ Node.js is required"; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "❌ npm is required"; exit 1; }
command -v git >/dev/null 2>&1 || { echo "❌ git is required"; exit 1; }

echo "✅ Prerequisites satisfied"

# Guide through setup
echo ""
echo "📋 Setup Steps:"
echo "1. Create accounts:"
echo "   - Railway: https://railway.app"
echo "   - Vercel: https://vercel.com"
echo "   - OpenAI: https://platform.openai.com"
echo "   - Slack: https://slack.com"
echo ""
echo "2. Configure environment:"
echo "   - Copy config/.env.*.template files"
echo "   - Fill in your values"
echo ""
echo "3. Deploy:"
echo "   - Run: ./deploy-facility.sh YOUR_FACILITY_NAME"
echo ""
echo "Need help? Contact support@clubos.com"
