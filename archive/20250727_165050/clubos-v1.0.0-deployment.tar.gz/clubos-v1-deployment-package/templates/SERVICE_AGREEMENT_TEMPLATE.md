# ClubOS Service Agreement Template

**This Service Agreement** ("Agreement") is entered into on [DATE] between ClubOS, Inc. ("Provider") and [FACILITY NAME] ("Client").

## 1. Services
Provider agrees to provide:
- ClubOS V1 golf simulator management platform
- Technical support during business hours
- Regular software updates and maintenance
- Data backup and recovery services

## 2. Fees
- Monthly subscription: $2,000
- Payment terms: Monthly in advance
- Late payment: 1.5% monthly interest

## 3. Term
- Initial term: Month-to-month
- Automatic renewal unless cancelled
- 30-day written notice required for cancellation

## 4. Service Level Agreement
- 99.9% uptime guarantee
- 4-hour response time for critical issues
- Daily automated backups
- Data retention: 30 days

## 5. Data & Privacy
- Client owns all data
- Provider ensures data security
- Compliance with privacy regulations
- Data export available upon request

## 6. Limitation of Liability
Provider's liability limited to monthly subscription fee.

## 7. Confidentiality
Both parties agree to maintain confidentiality.

**Client**: _______________________  
**Date**: _______________________

**Provider**: _______________________  
**Date**: _______________________
